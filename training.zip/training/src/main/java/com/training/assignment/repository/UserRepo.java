package com.training.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.training.assignment.model.User;

public interface UserRepo extends JpaRepository<User,Long>{

}
