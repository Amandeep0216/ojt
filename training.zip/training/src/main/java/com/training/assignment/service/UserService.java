package com.training.assignment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.assignment.model.User;
import com.training.assignment.repository.UserRepo;

@Service
public class UserService {

	@Autowired
	private UserRepo userRepo;
	
	public boolean validate(User user) {
		
		User val=userRepo.findById(user.getUser_id()).get();
		if((user.getUser_id()==val.getUser_id()) && user.getPassword().equals(val.getPassword())) {
		return true;
		}else {
			return false;
		}
		}
	}
