package com.assignment.training.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.training.model.Login;
import com.assignment.training.model.User;
import com.assignment.training.repo.UserRepo;

@Service
public class UserService {

	@Autowired
	private static UserRepo userRepo;

	
	
	public static boolean validate(Login login) {

		String email = login.getEmail();
		String password = login.getPassword();

		User user = userRepo.findByEmailAndPassword(email, password);

		return user != null;
	}
	}