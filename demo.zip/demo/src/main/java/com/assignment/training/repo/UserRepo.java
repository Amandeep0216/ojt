package com.assignment.training.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.assignment.training.model.User;

public interface UserRepo  extends JpaRepository<User, Long>{

	User findByEmailAndPassword(String email, String password);
	
}