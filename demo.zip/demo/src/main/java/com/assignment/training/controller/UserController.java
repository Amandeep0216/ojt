package com.assignment.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.training.model.Login;
import com.assignment.training.model.User;
import com.assignment.training.service.UserService;

@RestController
@RequestMapping("/auth")
public class UserController{
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/login")
	public boolean validateCustomer(Login login) {

		boolean isValidate = UserService.validate(login);

		return isValidate;
	}
	
	
}