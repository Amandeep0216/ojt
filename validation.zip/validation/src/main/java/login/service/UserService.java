package login.service;

import java.io.IOException;

import javax.ws.rs.Path; 


import login.dao.UserDao;
import login.model.User;

@Path("/login")
public class UserService {
	
	private static final long serialVersionUID = 1L;
		private UserDao userDao;

		public void init() {
			userDao = new UserDao();
		}

		public User validate(User user) {

			String username = request.getParameter("username");
			String password = request.getParameter("password");
			User user = new User();
			user.setUsername(username);
			user.setPassword(password);

			try {
				if (userDao.validate(user)) {
					
					return user;				
					} 
				else {
					return null; 
					
				}
			} catch (ClassNotFoundException e) {
				return null;
			}
		}
}
